

$freespace = gwmi win32_logicaldisk -filter "drivetype = 3" | select freespace | % { $_.deviceid; $_.freespace/1GB}
$fs = [int]$freespace[1]
$disksize = gwmi win32_logicaldisk -filter "drivetype = 3" | select size| % { $_.deviceid; $_.size/1GB}
$ds = [int]$disksize[1]
$percentfree = $fs/$ds*100

$instance = hostname

$dat = New-Object Amazon.CloudWatch.Model.MetricDatum
$dat.Timestamp = (get-date).ToUniversalTime()
$dat.MetricName = "$instance : Free Disk Space"
$dat.Unit = "Gigabytes"
$dat.Value = "$percentfree"
Write-CWMetricData -Namespace "DMT Metrics" -MetricData $dat
