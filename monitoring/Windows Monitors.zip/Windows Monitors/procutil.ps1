$procutil = get-counter -Counter "\Processor(_Total)\% Processor Time" -SampleInterval 1 | select CounterSamples | % { $_.CounterSamples} | %{ $_.CookedValue}
$instance = hostname

$dat = New-Object Amazon.CloudWatch.Model.MetricDatum
$dat.Timestamp = (get-date).ToUniversalTime()
$dat.MetricName = "$instance : CPU Utilization"
$dat.Unit = "percent"
$dat.Value = "$procutil"
Write-CWMetricData -Namespace "DMT Metrics" -MetricData $dat

