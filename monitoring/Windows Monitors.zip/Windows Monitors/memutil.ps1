
$memutil = get-counter '\Memory\Available MBytes' | select  CounterSamples | % { $_.deviceid; $_.CounterSamples } | % { $_.CookedValue}

$instance = hostname

$dat = New-Object Amazon.CloudWatch.Model.MetricDatum
$dat.Timestamp = (get-date).ToUniversalTime()
$dat.MetricName = "$instance : Memory Available"
$dat.Unit = "Megabytes"
$dat.Value = "$memutil"
Write-CWMetricData -Namespace "DMT Metrics" -MetricData $dat


